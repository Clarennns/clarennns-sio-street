<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <h1>Inscription</h1>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="index.php?controller=user&action=login">Connexion</a>
        </nav>
    </header>

    <section>
        <h2>Formulaire d'inscription</h2>
        <form action="index.php?controller=user&action=register" method="POST">
            <label for="nom">Nom :</label>
            <input type="text" name="nom" id="nom" required><br><br>
            
            <label for="prenom">Prénom :</label>
            <input type="text" name="prenom" id="prenom" required><br><br>

            <label for="email">Email :</label>
            <input type="email" name="email" id="email" required><br><br>

            <label for="password">Mot de passe :</label>
                 <input type="password" name="password" id="password" required
                     pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{8,}"
                     title="Au moins 8 caractères avec majuscule, minuscule, chiffre et caractère spécial."><br>
                 <small>Au moins 8 caractères, 1 majuscule, 1 minuscule, 1 chiffre, 1 caractère spécial.</small><br><br>

            <label for="role">Rôle :</label>
            <select name="role" id="role" required>
                <option value="client">Client</option>
                <option value="restaurateur">Restaurateur</option>
                <option value="vendeur">Vendeur</option>
            </select><br><br>

            <button type="submit">S'inscrire</button>
        </form>
    </section>
</body>
</html>
