<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($restaurant->getNom()); ?></title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <h1><?php echo htmlspecialchars($restaurant->getNom()); ?></h1>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="index.php?controller=restaurant&action=index">Restaurants</a>
            <a href="index.php?controller=menu&action=index">Menus</a>
        </nav>
    </header>

    <section>
        <h2>Informations</h2>
        <p>Ville : <?php echo htmlspecialchars($restaurant->getVille()); ?></p>
        <p>Adresse : <?php echo htmlspecialchars($restaurant->getAdresse()); ?></p>
        <p>Code Postal : <?php echo htmlspecialchars($restaurant->getCodePostal()); ?></p>
    </section>

    <section>
        <h2>Menus de ce restaurant</h2>
        <?php if (empty($menus)): ?>
            <p>Aucun menu associé pour le moment.</p>
        <?php else: ?>
            <ul>
                <?php foreach ($menus as $menu): ?>
                    <li>
                        <?php echo htmlspecialchars($menu->getNom()); ?> - <?php echo number_format($menu->getPrix(), 2, ',', ' '); ?> €
                        (<a href="index.php?controller=menu&action=show&id=<?php echo $menu->getId(); ?>">voir</a>)
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </section>
</body>
</html>
