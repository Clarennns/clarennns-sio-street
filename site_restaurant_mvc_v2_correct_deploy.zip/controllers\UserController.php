<?php
require_once 'models/User.php';

class UserController {
    private function isPasswordComplex($password) {
        // Au moins 8 caractères, 1 majuscule, 1 minuscule, 1 chiffre, 1 caractère spécial
        return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).{8,}$/', $password) === 1;
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = $_POST['nom'] ?? '';
            $prenom = $_POST['prenom'] ?? '';
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            $role = $_POST['role'] ?? 'client'; // rôle par défaut

            if (!empty($nom) && !empty($prenom) && !empty($email) && !empty($password) && !empty($role)) {
                if (!$this->isPasswordComplex($password)) {
                    echo "Le mot de passe doit contenir au moins 8 caractères, avec majuscule, minuscule, chiffre et caractère spécial.";
                    require_once 'views/user/Register.php';
                    return;
                }

                $existingUser = User::getByEmail($email);
                if (!$existingUser) {
                    $user = new User(null, $nom, $prenom, $email, $password, $role);
                    if ($user->save()) {
                        header('Location: index.php?controller=user&action=login');
                        exit();
                    } else {
                        echo "Erreur lors de la création de l'utilisateur.";
                    }
                } else {
                    echo "Cet email existe déjà.";
                }
            } else {
                echo "Veuillez remplir tous les champs.";
            }
        }
        require_once 'views/user/Register.php';
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';

            if (!empty($email) && !empty($password)) {
                $user = User::getByEmail($email);
                if ($user && $user->verifyPassword($password)) {
                    session_start();
                    $_SESSION['user_id'] = $user->getId();
                    $_SESSION['user_email'] = $user->getEmail();
                    $_SESSION['user_role'] = $user->getRole(); // si tu veux gérer des redirections plus tard
                    header('Location: index.php');
                    exit();
                } else {
                    echo "Identifiants incorrects.";
                }
            } else {
                echo "Veuillez remplir tous les champs.";
            }
        }
        require_once 'views/user/Login.php';
    }
}