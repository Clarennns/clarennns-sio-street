<?php
require_once 'controllers/MenuController.php';
require_once 'controllers/RestaurantController.php';
require_once 'controllers/UserController.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Routeur basique
$controller = isset($_GET['controller']) ? $_GET['controller'] : 'menu';
$action = isset($_GET['action']) ? $_GET['action'] : 'index';

// Créer le contrôleur dynamique
$controllerClass = ucfirst($controller) . 'Controller';
$controllerObject = new $controllerClass();

// Appeler l'action
if (isset($_GET['id'])) {
    $controllerObject->$action($_GET['id']);
} else {
    $controllerObject->$action();
}
?>