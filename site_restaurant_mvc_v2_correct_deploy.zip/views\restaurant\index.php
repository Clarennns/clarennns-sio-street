<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nos Restaurants</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <h1>Nos Restaurants</h1>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="index.php?controller=restaurant&action=index">Restaurants</a>
            <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'restaurateur'): ?>
                <a href="index.php?controller=restaurant&action=create">Ajouter un restaurant</a>
            <?php endif; ?>
        </nav>
    </header>

    <section>
        <h2>Tous les restaurants</h2>
        <div class="restaurants">
            <?php foreach ($restaurants as $restaurant): ?>
                <div class="restaurant">
                    <h3><?php echo htmlspecialchars($restaurant->getNom()); ?></h3>
                    <p>Ville : <?php echo htmlspecialchars($restaurant->getVille()); ?></p>
                    <p>Adresse : <?php echo htmlspecialchars($restaurant->getAdresse()); ?></p>
                    <p>Code Postal : <?php echo htmlspecialchars($restaurant->getCodePostal()); ?></p>
                    <a href="index.php?controller=restaurant&action=show&id=<?php echo $restaurant->getId(); ?>">Voir ses menus</a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</body>
</html>