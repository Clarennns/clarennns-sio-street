<?php
require_once 'models/Restaurant.php';
require_once 'models/Menu.php';

class RestaurantController {

    // Afficher tous les restaurants
    public function index() {
        // Récupérer tous les restaurants depuis la base de données
        $restaurants = Restaurant::getAll();
        
        // Charger la vue d'affichage des restaurants
        require 'views/restaurant/index.php';
    }

    // Illustrer l'association 1,N : un restaurant possède plusieurs menus
    public function show($id) {
        $restaurant = Restaurant::getById($id);

        if (!$restaurant) {
            header('Location: index.php?controller=restaurant&action=index');
            exit;
        }

        $menus = Menu::getByRestaurantId($id);
        require 'views/restaurant/show.php';
    }
}
?>