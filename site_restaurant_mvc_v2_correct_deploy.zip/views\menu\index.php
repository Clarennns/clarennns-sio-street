<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nos Menus</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <h1>Nos Menus</h1>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="index.php?controller=menu&action=index">Menus</a>
            <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'restaurateur'): ?>
                <a href="index.php?controller=menu&action=create">Ajouter un menu</a>
            <?php endif; ?>
        </nav>
    </header>

    <section>
        <h2>Tous les menus</h2>
        <div class="menus">
            <?php foreach ($menus as $menu): ?>
                <div class="menu">
                    <h3><?php echo htmlspecialchars($menu->getNom()); ?></h3>
                    <p>Prix : <?php echo number_format($menu->getPrix(), 2, ',', ' '); ?> €</p>
                    <a href="index.php?controller=menu&action=show&id=<?php echo $menu->getId(); ?>">Voir les plats</a>
                    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'restaurateur'): ?>
                        | <a href="index.php?controller=menu&action=edit&id=<?php echo $menu->getId(); ?>">Modifier</a>
                        <form action="index.php?controller=menu&action=delete&id=<?php echo $menu->getId(); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Supprimer ce menu ?');">
                            <button type="submit">Supprimer</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</body>
</html>