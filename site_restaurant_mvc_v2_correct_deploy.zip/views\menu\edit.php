<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un menu</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <h1>Modifier un menu</h1>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="index.php?controller=menu&action=index">Menus</a>
        </nav>
    </header>

    <section>
        <h2>Édition : <?php echo htmlspecialchars($menu->getNom()); ?></h2>

        <?php if (isset($error)): ?>
            <p style="color:red;"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form action="index.php?controller=menu&action=edit&id=<?php echo $menu->getId(); ?>" method="POST">
            <label for="nom">Nom du menu :</label>
            <input type="text" name="nom" id="nom" value="<?php echo htmlspecialchars($menu->getNom()); ?>" required><br><br>

            <label for="prix">Prix (€) :</label>
            <input type="number" name="prix" id="prix" step="0.01" min="0" value="<?php echo htmlspecialchars($menu->getPrix()); ?>" required><br><br>

            <label for="restaurant_id">Restaurant :</label>
            <select name="restaurant_id" id="restaurant_id" required>
                <?php foreach ($restaurants as $restaurant): ?>
                    <option value="<?php echo $restaurant->getId(); ?>" <?php echo ($menu->getRestaurantId() == $restaurant->getId()) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($restaurant->getNom()); ?>
                    </option>
                <?php endforeach; ?>
            </select><br><br>

            <button type="submit">Enregistrer</button>
        </form>
    </section>
</body>
</html>
