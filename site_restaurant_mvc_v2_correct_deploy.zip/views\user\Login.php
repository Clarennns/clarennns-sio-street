<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <h1>Connexion</h1>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="index.php?controller=user&action=register">Inscription</a>
        </nav>
    </header>

    <section>
        <h2>Formulaire de connexion</h2>
        <form action="index.php?controller=user&action=login" method="POST">
            <label for="email">Email :</label>
            <input type="email" name="email" id="email" required><br><br>

            <label for="password">Mot de passe :</label>
            <input type="password" name="password" id="password" required><br><br>

            <button type="submit">Se connecter</button>
        </form>
    </section>
</body>
</html>