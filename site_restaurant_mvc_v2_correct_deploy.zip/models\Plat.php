<?php
require_once 'config/database.php';

class Plat {
    private $id;
    private $nom;
    private $prix;

    public function __construct($id, $nom, $prix) {
        $this->id = $id;
        $this->nom = $nom;
        $this->prix = $prix;
    }

    // Getters
    public function getId() {
        return $this->id;
    }

    public function getNom() {
        return $this->nom;
    }

    public function getPrix() {
        return $this->prix;
    }

    // Méthode pour récupérer les plats d'un menu
    public static function getByMenuId($menuId) {
        // Connexion à la base de données
        $db = Database::connect();
        
        // Préparation de la requête SQL
        $stmt = $db->prepare("SELECT Plat.IDPlat, Plat.NomPlat, Plat.PrixPlat 
                             FROM Plat 
                             JOIN Choix_du_plat_dans_le_menu 
                             ON Plat.IDPlat = Choix_du_plat_dans_le_menu.IDPlat
                             WHERE Choix_du_plat_dans_le_menu.IDMenu = :menuId");
        
        // Liaison du paramètre :menuId à la variable
        $stmt->bindParam(':menuId', $menuId);
        
        // Exécution de la requête
        $stmt->execute();
        
        // Tableau des plats
        $plats = [];
        
        // Récupérer les résultats et les ajouter dans le tableau
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $plats[] = new Plat($row['IDPlat'], $row['NomPlat'], $row['PrixPlat']);
        }
        
        // Retourner les plats associés à ce menu
        return $plats;
    }
}
?>