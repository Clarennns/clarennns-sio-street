<?php
require_once 'config/database.php';

class Menu {
    private $id;
    private $nom;
    private $prix;
    private $restaurantId;

    public function __construct($id, $nom, $prix, $restaurantId = null) {
        $this->id = $id;
        $this->nom = $nom;
        $this->prix = $prix;
        $this->restaurantId = $restaurantId;
    }

    // Getters
    public function getId() {
        return $this->id;
    }

    public function getNom() {
        return $this->nom;
    }

    public function getPrix() {
        return $this->prix;
    }

    public function getRestaurantId() {
        return $this->restaurantId;
    }

    // Méthode pour récupérer tous les menus
    public static function getAll() {
        $db = Database::connect();
        $stmt = $db->query("SELECT * FROM Menu");
        $menus = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $menus[] = new Menu($row['IDMenu'], $row['NomMenu'], $row['PrixMenu'], $row['IDRestaurant'] ?? null);
        }
        return $menus;
    }

    // Méthode pour récupérer un menu par son ID
    public static function getById($id) {
        $db = Database::connect();
        $stmt = $db->prepare("SELECT * FROM Menu WHERE IDMenu = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            return new Menu($row['IDMenu'], $row['NomMenu'], $row['PrixMenu'], $row['IDRestaurant'] ?? null);
        }
        
        return null;  // Si aucun menu n'est trouvé, on retourne null
    }

    public static function getByRestaurantId($restaurantId) {
        $db = Database::connect();
        $stmt = $db->prepare("SELECT * FROM Menu WHERE IDRestaurant = :restaurantId ORDER BY IDMenu DESC");
        $stmt->bindParam(':restaurantId', $restaurantId);
        $stmt->execute();

        $menus = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $menus[] = new Menu($row['IDMenu'], $row['NomMenu'], $row['PrixMenu'], $row['IDRestaurant'] ?? null);
        }
        return $menus;
    }

    public static function create($nom, $prix, $restaurantId) {
        $db = Database::connect();
        $stmt = $db->prepare("INSERT INTO Menu (NomMenu, PrixMenu, IDRestaurant) VALUES (:nom, :prix, :restaurantId)");
        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':prix', $prix);
        $stmt->bindParam(':restaurantId', $restaurantId);
        return $stmt->execute();
    }

    public static function update($id, $nom, $prix, $restaurantId) {
        $db = Database::connect();
        $stmt = $db->prepare("UPDATE Menu SET NomMenu = :nom, PrixMenu = :prix, IDRestaurant = :restaurantId WHERE IDMenu = :id");
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':prix', $prix);
        $stmt->bindParam(':restaurantId', $restaurantId);
        return $stmt->execute();
    }

    public static function delete($id) {
        $db = Database::connect();
        $stmt = $db->prepare("DELETE FROM Menu WHERE IDMenu = :id");
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}
?>